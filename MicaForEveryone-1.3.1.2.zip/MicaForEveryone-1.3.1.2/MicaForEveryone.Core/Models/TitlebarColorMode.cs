﻿using System.Runtime.InteropServices;

namespace MicaForEveryone.Core.Models
{
    [ComVisible(true)]
    public enum TitlebarColorMode
    {
        Default = 0,
        Light = 1,
        Dark = 2,
        System = 3,
    }
}
