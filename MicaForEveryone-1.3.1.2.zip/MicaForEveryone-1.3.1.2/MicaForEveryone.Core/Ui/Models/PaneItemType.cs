﻿namespace MicaForEveryone.Core.Ui.Models
{
    public enum PaneItemType
    {
        General,
        Global,
        Process,
        Class,
    }
}
