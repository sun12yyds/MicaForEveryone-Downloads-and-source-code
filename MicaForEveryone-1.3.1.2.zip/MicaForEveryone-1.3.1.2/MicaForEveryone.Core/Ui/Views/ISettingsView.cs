﻿namespace MicaForEveryone.Core.Ui.Views;

public interface ISettingsView
{
    void Close();
}