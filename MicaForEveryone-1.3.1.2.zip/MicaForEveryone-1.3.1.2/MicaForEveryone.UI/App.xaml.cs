﻿namespace MicaForEveryone.UI
{
    public sealed partial class App
    {
        public App()
        {
            Initialize();
        }
    }
}
