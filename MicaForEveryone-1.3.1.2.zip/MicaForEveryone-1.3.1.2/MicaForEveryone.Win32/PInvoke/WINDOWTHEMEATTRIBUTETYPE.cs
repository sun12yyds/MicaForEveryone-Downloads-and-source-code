﻿namespace MicaForEveryone.Win32.PInvoke
{
    public enum WINDOWTHEMEATTRIBUTETYPE
    {
        /// <summary>Non-client area window attributes will be set.</summary>
        WTA_NONCLIENT = 1,
    }
}
