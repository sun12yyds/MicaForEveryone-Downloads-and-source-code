﻿namespace MicaForEveryone.Win32.PInvoke
{
    internal enum WindowCompositionAttribute
    {
        WCA_ACCENT_POLICY = 19
    }
}
