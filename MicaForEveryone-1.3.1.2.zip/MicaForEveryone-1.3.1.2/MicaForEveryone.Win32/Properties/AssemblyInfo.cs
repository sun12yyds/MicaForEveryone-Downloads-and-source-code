using System.Reflection;

[assembly: AssemblyTitle("MicaForEveryone.Win32")]
[assembly: AssemblyProduct("Mica For Everyone Win32 Helper Library")]
[assembly: AssemblyCompany("Mica For Everyone")]
[assembly: AssemblyCopyright("Copyright (C) 2021-2022 Mohammad Amin Mollazadeh and Contributers")]
