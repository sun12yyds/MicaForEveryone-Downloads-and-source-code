﻿using System.Reflection;

[assembly: AssemblyVersion("1.3.1.2")]
[assembly: AssemblyFileVersion("1.3.1.2")]
[assembly: AssemblyInformationalVersion("1.3.1.2")]
