﻿namespace MicaForEveryone.Core.Ui.Views;

public interface ITrayIconView
{
    void Close();
}