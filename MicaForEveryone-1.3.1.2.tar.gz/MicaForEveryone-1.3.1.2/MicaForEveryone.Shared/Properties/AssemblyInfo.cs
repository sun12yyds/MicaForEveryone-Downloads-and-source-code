using System.Reflection;

[assembly: AssemblyTitle("MicaForEveryone.Shared")]
[assembly: AssemblyProduct("Mica For Everyone UWP/.NET Interface Library")]
[assembly: AssemblyCompany("Mica For Everyone")]
[assembly: AssemblyCopyright("Copyright (C) 2021-2022 Mohammad Amin Mollazadeh and Contributers")]
